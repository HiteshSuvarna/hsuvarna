<!DOCTYPE html>
<html lang="en">
<head>
	<title>Ascend Educators - Enquiry Form</title>
	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	
	<script>
		$(document).ready(function() {
			$("#enquiry").submit(function(event) {
				event.preventDefault();
				
				var first_name = $("#first_name").val();
				var last_name = $("#last_name").val();
				var address = $("#address").val();
				var phone1 = $("#phone1").val();
				var phone2 = $("#phone2").val();
				var phone3 = $("#phone3").val();
				var email = $("#email").val();
				var course = $("#course").val();
				var gender = $("#gender").val();

				var flg=false;

				$('.form_need').empty();
				if(first_name == "") {
					$('.form_need').append("<li>First Name.</li>");
					flg = true;
				}

				if(phone1 == "") {
					$('.form_need').append("<li>Phone 1.</li>");
					flg= true;
				}

				if(email == "") {
					$('.form_need').append("<li>Email.</li>");
					flg = true;
				}		

				if (flg == true) {
					$('#failure_form').modal('show');
				} else {

					$.post("<?php echo base_url().'index.php/Enquiry/save'; ?>", 
						{
							"first_name" : first_name,
							"last_name" : last_name,
							"address" : address,
							"phone1" : phone1,
							"phone2" : phone2,
							"phone3" : phone3,
							"email" : email,
							"course" : course,
							"gender" : first_name
						}, function(data, status, xhr) {
							if(status == "success") {
								//SUCCESS
								$("#first_name").val("");
								$("#last_name").val("");
								$("#address").val("");
								$("#phone1").val("");
								$("#phone2").val("");
								$("#phone3").val("");
								$("#email").val("");
								$("#course").val("");
								$("#gender").val("");

								$('.u_name').html(first_name);
								$('#success_done').modal('show');
							} else {
								//ERROR

								$('.u_name').html(first_name);
								$('#failure').modal('show');
							}
						},
						"text"
					);
				}
			});
		});		
	</script>
</head>
<body style="background-color:#ffcc00;color:white;">
	<!-- <div class="navbar" style="background-color:#ffcc00;">
		<div class="navbar-header">
    		<a class="navbar-brand" href="#">
    			<img src="logo.png" style="" alt="logo" />
    		</a>
    	</div>
		<ul class="nav navbar-nav navbar-right">
			<li class="active"><a href="#">Home</a></li>
			<li><a href="#">Page 1</a></li>
			<li><a href="#">Page 2</a></li>
			<li><a href="#">Page 3</a></li>
		</ul>

		<div align="left">
			
		<h3></h3>
		</div>
		
	</div> -->
	<div id="success_done" class="modal fade" role="dialog">
		<div class="modal-dialog">
			<div align="center" class="modal-body" style="background-color:#ffcc00;color:white;">
				<h1>Thank you for showing interest,<b class="u_name"></b>. :)</h1>
				<h2>We really appriciate</h2>
				<br>
				<h1>We will get back to you.</h1>
		<!-- 		<div class="row">
					<div class="col-sm-12"> -->
						<a href="https://www.facebook.com/Ascend-Educators-927782920681551/">
							<button class="btn btn-lg">
								Like us on Facebook :)
							</button>
						</a>
					<!-- </div>
				</div> -->
		
			</div>
		</div>
	</div>
	<div id="failure" class="modal fade" role="dialog">
		<div class="modal-dialog">
			<div align="center" class="modal-body" style="background-color:#ff0000;color:white;">
				<h1>Well <b class="u_name"></b>, something went wrong. Can you try again?</h1>
				<h2>Sorry about that</h2>
				<br>
				
		<!-- 		<div class="row">
					<div class="col-sm-12"> -->
						<a href="https://www.facebook.com/Ascend-Educators-927782920681551/">
							<button class="btn btn-lg">
								Like us on Facebook :)
							</button>
						</a>
					<!-- </div>
				</div> -->
		
			</div>
		</div>
	</div>
	<div id="failure_form" class="modal fade" role="dialog">
		<div class="modal-dialog">
			<div align="center" class="modal-body" style="background-color:#ff0000;color:white;">
				<h1>Well <b class="u_name"></b>, you seem to have missed out on a few things.</h1>
				<h2>Sorry about that, but then thats needed.</h2>
				<br>
				
				<h2 align="left"><ul class="form_need"></ul></h2>
		
			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-sm-6" align="center">
			<div class="row">
				<div class="col-sm-12">
					<img src="<?php echo base_url().'assets/images/logo_lg.png'; ?>" />
				</div>
			</div>

			<div class="row">
				<div class="col-sm-12">
					<h3><i>-We make you #oneofakind</i></h3>
				</div>
			</div>

			<div class="row">
				<div class="col-sm-3"></div>
				<div class="col-sm-3">
					<a href="http://www.ascendeducators.com"><button class="btn btn-block btn-warning">For Further info</button></a>
				</div>
				<div class="col-sm-3"></div>
			</div>
		</div>
		<div class="col-sm-5" style="background-color:#fff;color:#ffcc00;">
			<div class="row">
				<div class="col-sm-12">
				<h3>Full up the form to get started!! :D </h3>
				</div>
			</div>
			<div class="row">
				<form method="post" id="enquiry" role="form">
					<div class="col-sm-12">
						<div class="form-group">
							<label>First Name</label>
							<input class="form-control" type="text" id="first_name" name="first_name">
						</div>
						<div class="form-group">
							<label>Last Name</label>
							<input class="form-control" id="last_name" type="text" name="last_name">
						</div>
						<div class="form-group">
							<label>Address</label>
							<textarea id="address" name="address" class="form-control" ></textarea>
						</div>
						<div class="form-group">
							<label>Phone 1</label>
							<input type="text" id="phone1" name="phone1" class="form-control" >
						</div>
						<div class="form-group">	
							<label>Phone 2</label>
							<input type="text" id="phone2" name="phone2" class="form-control" >
						</div>
						<div class="form-group">	
							<label>Phone 3</label>
							<input type="text" id="phone3" name="phone3" class="form-control" >
						</div>
						<div class="form-group">
							<label>Email</label>
							<input type="text" id="email" name="email" class="form-control" >
						</div>
						<div class="form-group">
							<label>Course Name</label>
							<select name="course" id="course" class="form-control" >
								<option value="cs">Computer Science</option>
								<option value="it">Information Technology</option>
							</select>
						</div>
						<div class="form-group">
							<label>Gender</label>
							<select name="gender" id="gender" class="form-control" >
								<option value="male">Male</option>
								<option value="female">Female</option>
							</select>
						</div>
						<div class="form-group">
							<label>How did you get out reference</label>
							<select name="refer" class="form-control" >
								<option value="friend">A Friend Informed you</option>
								<option value="sms">Some SMS you recieved</option>
								<option value="website">Our website</option>
								<option value="other">Some other source</option>
							</select>
						</div>
						<div>
							<input id="submit" type="submit" class="btn btn-success btn-block">
						</div>
					</div>
				</form>
			</div>
		</div>
		<div class="col-sm-1"></div>

	</div>
</body>
</html>