<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Public Portal</title>
	<link rel="stylesheet" href="<?php echo base_url().'/assets/css/bootstrap.min.css'; ?>">
	<script src="<?php echo base_url().'/assets/js/jquery.min.js'; ?>"></script>
	<script src="<?php echo base_url().'/assets/js/bootstrap.min.js'; ?>"></script>
	<script src="<?php echo base_url().'/assets/js/Chart.js'; ?>"></script>
	
	<style type="text/css">

	</style>
</head>
<body>
<nav class="navbar">
	<div class="container-fluid">
    	<div class="navbar-header">
    		<a class="navbar-brand" href="#">Hack 4 People</a>
    	</div>
		<ul class="nav navbar-nav">
			<li><a href="<?php echo base_url().'index.php/HPublic/home'; ?>">Home</a></li>
			<li><a href="<?php echo base_url().'index.php/HPublic/opinions'; ?>">Opinions and Dicsussions</a></li>
			<!-- <li><input type="text" class="form-control" name=""></li> -->
			<!-- <li><a href="#">Check Application Status</a></li> -->
		</ul>
		<ul class="nav navbar-nav navbar-right">
			<li class="dropdown">
			<a class="dropdown-toggle" data-toggle="dropdown" href="#">My Account<span class="caret"></span></a>
			<ul class="dropdown-menu" style="padding: 15%;align:right;" align="center">
				<li>Hello Hitesh</li>
				<li><a href="#">Logout</a></li>
			</ul>
			</li>
		</ul>
	</div>

</nav>
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-12" style="background-color: #1e434c; color: #fff;max-height: 100%;box-shadow: 0px 5px 2px #000;">
			<div class="row" style="margin: 1%;">
				<h3>Raise an opinion to make a difference.</h3>
				<div class="col-sm-12 well well-lg" style="color: #1e434c;">
					<div class="form-group">
						<label>Opinion Title</label>
						<input type="text" name="" class="form-control" placeholder="Write your title here.">
					</div>
					<div class="form-group">
						<label>Description</label>
						<textarea class="form-control" placeholder="Provide the entire description. Max Charecter 900."></textarea>
					</div>
				</div>
				
				<div class="col-sm-4">
					<button class="btn btn-warning btn-block">Submit</button>
				</div>
				<div class="col-sm-8"></div>
			</div>
			<div class="row">
				<div class="col-sm-4"></div>
				<div class="col-sm-8" align="right">
					<h4>Opinions posted by people to get society reforms</h4>
					<hr>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12">
					<div style="max-height:100%; overflow-y: scroll;">
					<ul class="list-group" style="color: #1e434c;">
						<li class="list-group-item">
							<div>
								<h3>Do we need wider roads?</h3>
								<small>We are facing huge traffic problems. As a result of which we are not able to ....</small>
								<div align="right">
									<em id="opinion1_yes_view" style="background-color: green; color: #fff;padding: 1%;border-radius: 3px;box-shadow: 0px 2px 3px #000;">49</em>
									<em id="opinion1_no_view" style="background-color: red; color: #fff;padding: 1%;border-radius: 3px;box-shadow: 0px 2px 3px #000;">2</em>
									<div style="margin-top: 2%;"><em>Raised on 30/10/2016 by <b>Mr. Kumar (Director, PWD)</b></em></div>
								</div>
								<div align="rig">
									<button type="button" data-toggle="modal" data-target="#opinion1" class="btn btn-xs" style="background-color: #1e434c; color: #fff;">View Details</button>
								</div>
							</div>

						</li>
						<li class="list-group-item">
							<div>
								<h3>A better power generating mechnaism to prevent frequent failures</h3>
								<small>In our kerela we have obsereved frequent power failure, which results in a lot ....</small>
								<div align="right">
									<em id="opinion2_yes_view" style="background-color: green; color: #fff;padding: 1%;border-radius: 3px;box-shadow: 0px 2px 3px #000;">103</em>
									<em id="opinion2_no_view" style="background-color: red; color: #fff;padding: 1%;border-radius: 3px;box-shadow: 0px 2px 3px #000;">0</em>
									<div style="margin-top: 2%;"><em>Raised on 12/10/2016 by <b>Mr. Nair (Executive, Electricity Supply Board)</b></em></div>
								</div>
								<div align="rig">
									<button  type="button" data-toggle="modal" data-target="#opinion2" class="btn btn-xs" style="background-color: #1e434c; color: #fff;">View Details</button>
								</div>
							</div>
						</li>						
					</ul>
					</div>
				</div>
				
			</div>
		</div>	
	</div>
<div id="opinion1" class="modal fade" role="dialog">
	<div class="modal-dialog">
		
	<!-- Modal content-->
		<div class="modal-content">
			<!-- <div class="alert alert-success" id="allot_success1">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Success!</strong> Succefully Alloted.
			</div> -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Do we need wider roads?</h4>
			</div>
			<div class="modal-body">
				<div><i> - Mr. Kumar, Director, PWD.</i></div>
				<div><i>Raised on 30/10/2016</i></div>


				<div align="right">
					<em><button id="opinion1_yes" style="background-color: green; color: #fff;padding: 2%;border-radius: 3px;box-shadow: 0px 2px 3px #000;"></button></em>
					<button id="opinion1_no" style="background-color: red; color: #fff;padding: 2%;border-radius: 3px;box-shadow: 0px 2px 3px #000;"><em></em></button>
				</div>
				<div class="form-group">
					<label>Details</label>
					<p>
					We are facing huge traffic problems. As a result of which we are not able to make moves faster. In 2010, Politicians in Kerala, cutting across party lines, decided to restrict the width of National Highways in the State to 30 meters. Later, through the intervention of the National Highways Authority of India (NHAI), it was decided to have 45 meters width with 4 lanes, wherever possible and 30 meters, in other places, at a time when other States opted for NHs with minimum 60 meters width with 6 lanes.</p>

					<p>Today, the average speed on the NHs in Kerala is about 30 Km/hr. On an average, 12 deaths are reported daily on account of accidents on NHs. The amount of time, money, manpower, fuel and other resources wasted on these NHs because of slow moving traffic has never been calculated.</p>

					<p>Looking at the growth of vehicular traffic, what we need is NHs with minimum 70 meters width with 8 lanes (4 + 4 dual carriageway). Wherever land acquisition is a problem, like in junctions or severely congested areas, there should be flyovers and we also need bypass for all major cities on the NHs - Kollam, Alappuzha, Kozhikode and Kannur.</p>

					<p>After three years, now the State Government is pushing the Union Ministry of Road Transport and Highways to agree to reduce the width of NH being developed in the State from 45 metres to 30 metres. But the NHAI is opposing this. NHAI has already scrapped six projects in Kerala due to non-availability of land which is the responsibility of the State Government.</p>
				</div>
				<label>Comments</label>
				<hr>
				<div class="row">
					<div class="col-sm-1"></div>
					<div class="col-sm-11">
						<div>
							<ul class="list-group">
								<li class="list-group-item">
									<label>Mr Chintan</label>
									<div align="right">01/11/2016</div>
									<div>Yes we do need wider roads, as vehicles in kerela are on the rise. This will lead to faster commute</div>

								</li>
								<li class="list-group-item">
									<label>Mr Ravi</label>
									<div align="right">01/11/2016</div>
									<div>70 meters width with 8 lanes (4 + 4 dual carriageway) would be really great.</div>

								</li>
								<li class="list-group-item" style="background-color: green;color: white;">
									<label>Mr Gujral</label>
									<div align="right">02/11/2016</div>
									<div>Let us consider what budget will be alloted to us by the government.</div>

								</li>
							</ul>
						</div>
					</div>
					
				</div>

			</div>
			<div class="modal-footer">
				<div class="form-group">
					<label>Add a comment</label>
					<textarea class="form-control"></textarea>
				</div>
				<button class="btn btn-success">Submit</button>
			</div>
		</div>
	</div>
</div>

<div id="opinion2" class="modal fade" role="dialog">
	<div class="modal-dialog">
		
	<!-- Modal content-->
		<div class="modal-content">
			<!-- <div class="alert alert-success" id="allot_success1">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Success!</strong> Succefully Alloted.
			</div> -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">A better power generating mechnaism to prevent frequent failures</h4>
			</div>
			<div class="modal-body">
				<div><i> - Mr. Nair, Executive, Electricity Supply Board.</i></div>
				<div><i>Raised on 12/10/2016</i></div>


				<div align="right">
					<em><button id="opinion2_yes" style="background-color: green; color: #fff;padding: 2%;border-radius: 3px;box-shadow: 0px 2px 3px #000;"></button></em>
					<em><button id="opinion2_no" style="background-color: red; color: #fff;padding: 2%;border-radius: 3px;box-shadow: 0px 2px 3px #000;"></button></em>
				</div>
				<div class="form-group">
					<label>Details</label>
					<p>
					In our kerela we have obsereved frequent power failure, which results in a lot Kerala State Electricity Board, constituted by the Government of Kerala, by order dated 7.3.1957, under the Electricity (Supply) Act, 1948 is in the business of Generation, Transmission and Distribution of electricity and striving to provide quality electricity at affordable cost to all classes of consumers in the state of Kerala. As per section 172 (a) of the Electricity Act 2003 and as mutually decided by the Government of India and Government of Kerala, KSEB has continued as Transmission utility and Distribution licensee till 24-09-2008. In exercise of powers conferred under sub-sections (1), (2), (5), (6) and (7) of section 131 of the Electricity Act, 2003, State Government vide the notification G.O (Ms).37/2008/PD dated 25 September 2008 has vested all functions, properties, interests, rights, obligations and liabilities of KSEB with the State Government till it is re-vested the same in a corporate entity. Accordingly, KSEB has been continuing all the functions as a Generator, State Transmission Utility and a Distribution Licensee in the State. Kerala State Electricity Board commenced functioning on 31-3-1957 After Noon as per order no. EL1-6475/56/PW dated 7-3-1957 of the Kerala State Government..</p>
				</div>
				<label>Comments</label>
				<hr>
				<div class="row">
					<div class="col-sm-1"></div>
					<div class="col-sm-11">
						<div>
							<ul class="list-group">
								<li class="list-group-item">
									<label>Mr Mahesh</label>
									<div align="right">14/10/2016</div>
									<div>Kerala State Electricity Board, constituted by the Government of Kerala, by order dated 7.3.1957, under the Electricity (Supply) Act, 1948 is in the business of Generation, Transmission and Distribution of electricity and striving to provide quality electricity at affordable cost to all classes of consumers in the state of Kerala</div>

								</li>
								<li class="list-group-item" style="background-color: green;color: white;">
									<label>Mr Ravi</label>
									<div align="right">01/11/2016</div>
									<div>Renewalble sources are great. We must implement them always.</div>

								</li>
								<li class="list-group-item">
									<label>Mr Gujral</label>
									<div align="right">02/11/2016</div>
									<div>Let us consider what budget will be alloted to us by the government.</div>

								</li>
							</ul>
						</div>
					</div>
					
				</div>

			</div>
			<div class="modal-footer">
				<div class="form-group">
					<label>Add a comment</label>
					<textarea class="form-control"></textarea>
				</div>
				<button class="btn btn-success">Submit</button>
			</div>
		</div>
	</div>
</div>

<script>
	$('#allot_success1').modal('hide');
	$(document).ready(function(){
		var opinion1yes = 49;
		var opinion1no = 23;
		var opinion2yes = 123;
		var opinion2no = 0;

		$('#opinion1_yes').html(opinion1yes);
		$('#opinion1_no').html(opinion1no);
		$('#opinion2_yes').html(opinion2yes);
		$('#opinion2_no').html(opinion2no);
		$('#opinion1_yes_view').html(opinion1yes);
		$('#opinion1_no_view').html(opinion1no);
		$('#opinion2_yes_view').html(opinion2yes);
		$('#opinion2_no_view').html(opinion2no);
		
		$('#opinion1_yes').click(function(){
			opinion1yes++;
			$('#opinion1_yes').html(opinion1yes);
			$('#opinion1_yes_view').html(opinion1yes);
		});
		
		$('#opinion1_no').click(function(){
			opinion1no++;
			$('#opinion1_no').html(opinion1no);
			$('#opinion1_no_view').html(opinion1no);
		});
		
		$('#opinion2_yes').click(function(){
			opinion2yes++;
			$('#opinion2_yes').html(opinion2yes);
			$('#opinion2_yes_view').html(opinion2yes);
		});
		
		$('#opinion2_no').click(function(){
			opinion2no++;
			$('#opinion2_no').html(opinion2no);
			$('#opinion2_no_view').html(opinion2no);
		});
		
	});

</script>

</div>
</body>
</html>