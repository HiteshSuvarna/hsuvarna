<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Public Portal</title>
	<link rel="stylesheet" href="<?php echo base_url().'/assets/css/bootstrap.min.css'; ?>">
	<script src="<?php echo base_url().'/assets/js/jquery.min.js'; ?>"></script>
	<script src="<?php echo base_url().'/assets/js/bootstrap.min.js'; ?>"></script>

	<style type="text/css">

	</style>
</head>
<body>
<nav class="navbar">
	<div class="container-fluid">
    	<div class="navbar-header">
    		<a class="navbar-brand" href="#">Hack 4 People</a>
    	</div>
		<ul class="nav navbar-nav">
			<li><a href="<?php echo base_url().'index.php/Search'; ?>">Home</a></li>
			<li><a href="<?php echo base_url().'index.php/Search'; ?>">About</a></li>
		</ul>
		<ul class="nav navbar-nav navbar-right">
			<li><a href="<?php echo base_url().'index.php/Search'; ?>">Login</a></li>
		</ul>
	</div>

</nav>
<div class="container">
	<h1>Welcome to the public portal</h1>
	<h3>Simple raise a query that you wish to know.<br>Continue By Registering or Login</h3>
	<hr>
	<div class="row">
		<form method="POST" action="<?php echo base_url().'index.php/HPublic/home'; ?>">
		<div class="col-sm-4">
			<div class="form-group">
				<label>Enter your Aadhar Number</label>
				<input type="text" name="aadhar_register" class="form-control">
			</div>
			<div class="form-group">
				<label><input type="checkbox" id="terms_check" value="Done">You agree to terms and conditions.</label>
			</div>
			<input type="submit" class="btn btn-success" value="Register">
		</div>
		<div class="col-sm-4"></div>
		<div class="col-sm-4"></div>
	</div>
</div>

</body>
</html>