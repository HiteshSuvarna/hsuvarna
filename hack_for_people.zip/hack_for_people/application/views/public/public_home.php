<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Public Portal</title>
	<link rel="stylesheet" href="<?php echo base_url().'/assets/css/bootstrap.min.css'; ?>">
	<link rel="stylesheet" href="<?php echo base_url().'/assets/css/jquery-ui.css'; ?>">
	<script src="<?php echo base_url().'/assets/js/jquery.min.js'; ?>"></script>
	<script src="<?php echo base_url().'/assets/js/bootstrap.min.js'; ?>"></script>
	<script src="<?php echo base_url().'/assets/js/Chart.js'; ?>"></script>
	<script src="<?php echo base_url().'/assets/js/jquery-ui.js'; ?>"></script>
	
	<style type="text/css">

	</style>
	  <script>
  $( function() {
    var projects = [
      {
        value: "1",
        label: "What is fine for jumping a signal?",
        desc: "When you jump a signal, you are liable to pay Rs. 100/-.",
        icon: "jquery_32x32.png",
        main_desc : "Next time you jump a traffic signal, don't think you were lucky to give a policeman a slip. For, you may not be that lucky to miss a postal notice at your doorstep.In the wake of increasing traffic rule violations, the police have begun sending the notices to the homes of violators. If the notice is ignored, they will have to pay the fine in the court. Majority of violations include signal jumping, triple riding, using phone while driving, etc. Starting May 1, constables have been building a record of vehicle numbers, timing, violation details, date and place of occurrence at all traffic stations. Subsequently, police officers will check details of vehicle owners and their addresses and will send notices through posts or staff. Within three days, a traffic police station has recorded over 150 cases. "
      },
      {
        value: "2",
        label: "What if someone asks for bribe?",
        desc: "Tell them this is bullshit.",
        icon: "jqueryui_32x32.png",
        main_desc : "So what are you to do? First, let me commend you on the position you've taken. You did not pay the bribe. That's the basic expectation of an FTI member. As you are aware, you've signed FTI's Code of Conduct by joining FTI. If even FTI members start paying bribes, we will have little strength left to fight corruption. When Indian soldiers fight the enemy on the border, they give up their life itself in battling the enemy. Fighting corruption only involves inconvenience. FTI members should at least fight the enemy that lives within India. Giving up without a fight will amount to abject failure. Even if we pay Rs.200 in bribes, it will support the politicians (through bribe-taking officers) who are destroying India. Every rupee in bribe strengthens India's enemies and weakens our resolve and capacity to fight the enemy."
      },
      {
        value: "3",
        label: "Do i have to pay water taxes every month?",
        desc: "No that can be paid quarterly.",
        icon: "sizzlejs_32x32.png",
        main_desc : "Just until a few years ago, water and sewerage tax was paid as part of the Property Tax in Chennai city.  However, after the formulation of the Chennai Metropolitan Water supply and Sewerage Board, Water and Sewerage taxes have to be paid separately.  Following are some facts: The Water and Sewerage tax form 30% of the Property Tax. Property Tax rates in Chennai are revised once in every 5 years.  It is levied on properties such as buildings, land and all other immovable property. The following briefly describes the steps involved in the process: The first step is the assessment of property tax for your property. If you are satisfied with the assessment, you can pay the property tax once in every six months. If you are unsatisfied with the property tax assessment, you may appeal to the Chairman, Taxation Appeal Tribunal.  We will look in detail each of the steps mentioned above regarding property tax."
      },
      {
        value: "3",
        label: "Where do i go if a police official harrases me?",
        desc: "Well, you can lodge a complaint at mainoffice@police.com. An action will be taken against it.",
        icon: "sizzlejs_32x32.png",
        main_desc : "There is no shortage of advice out there about what you should do when you are forced to interact with the police. Just do a search and you’ll find a multitude of sites devoted to explaining what your rights are when dealing with law enforcement and how you should go about asserting those rights. But, strangely enough, there is an absolute lack of advice available out there about what you should do once a police officer violates those rights… and there will be no shortage of questions you’ll have once it happens to you. I know this because there is no shortage of people who write me asking those questions when they become victims of police misconduct. So, I’ve compiled a general guide for victims of police misconduct that gives some general guidelines that, hopefully, answer a lot of those questions you’ll have once you become a victim of police misconduct… and I do hope that you’ll never have to follow this advice. First, I must make it clear that I am not a lawyer, please keep this in mind. The following advice is based on my experiences as a victim of police misconduct, an advocate for other victims, and a researcher studying the issues of police misconduct. Therefore, the following tips should not be considered as legal advice and are merely general recommendations that may or may not apply equally in all states or localities."
      },
      {
        value: "3",
        label: "What qualifications do you need to be a police officer",
        desc: "You must pass out a Police Examiation, which checks up your fitness & sharpness.",
        icon: "sizzlejs_32x32.png",
        main_desc : "Preferred Characteristics A police officer career is suited to anyone who thrives on challenges. You must be at least 21 years old and pass competitive written exams in order to become a police officer. Being agile and in good shape is also important, because police officers have to be fast on their feet. Participating in sports and taking physical education classes can prepare you to meet the rigorous physical qualifications of police officer jobs. Developing strong interpersonal skills is also a must since you will have frequent contact with the public. Education Requirements : Police officer education requirements range from a high school diploma to a college degree. The minimum requirement is usually a high school diploma, although an increasing number of police departments require applicants to complete at least one or two years of college coursework or have an associate’s degree. A bachelor’s degree is the minimum requirement for federal police jobs. In urban police departments and federal agencies, knowing how to speak a foreign language is considered a plus. Relevant Areas of Study : Most aspiring police officers pursue degrees in criminal justice. In criminal justice degree programs, students learn about every aspect of the law and justice system. Criminal justice is an interdisciplinary field that incorporates the study of law, psychology, sociology, public administration, and more. Other relevant majors that students thinking of joining the police force may pursue include police science and political science. Most police departments prefer applicants with a degree, regardless of their major. Police Academy Training : Prior to taking on assignments, police officers go through training at a police academy. The training program generally lasts around 12 to 14 weeks and includes classroom instruction in state laws, local ordinances, constitutional law, civil rights, and accident investigation. Police officers also learn about traffic control, self-defense, first-aid, firearms, and emergency response."
      },
      {
        value: "create_new",
        label: "Unable to find results? Post a query.",
        desc: "",
        icon: "sizzlejs_32x32.png",
        main_desc : ""
      },

    ];
 
    $( "#querysearch" ).autocomplete({
      minLength: 0,
      source: projects,
      focus: function( event, ui ) {
        $( "#querysearch" ).val( ui.item.label );
        return false;
      },
      select: function( event, ui ) {
  		$( "#querysearch" ).val( ui.item.label );
        $( "#project-id" ).val( ui.item.value );
        $( "#project-description" ).html( ui.item.main_desc );
        $( "#project-icon" ).attr( "src", "images/" + ui.item.icon );
 		
        return false;
      }
    })
    .autocomplete( "instance" )._renderItem = function( ul, item ) {
      return $( "<li>" )
        .append( "<div><h3>" + item.label + "</h3><em>" + item.desc + "</em></div>" )
        .appendTo( ul );
    };

    $('#querysearch').focusout(function(){
    	$( "#project-description" ).hide();
        $('#raise_query').show();
        
    });
  } );
  </script>
</head>
<body>
<nav class="navbar">
	<div class="container-fluid">
    	<div class="navbar-header">
    		<a class="navbar-brand" href="#">Hack 4 People</a>
    	</div>
		<ul class="nav navbar-nav">
			<li><a href="<?php echo base_url().'index.php/HPublic/home'; ?>">Home</a></li>
			<li><a href="<?php echo base_url().'index.php/HPublic/opinions'; ?>">Opinions and Dicsussions</a></li>
			<!-- <li><input type="text" class="form-control" name=""></li> -->
			<!-- <li><a href="#">Check Application Status</a></li> -->
		</ul>
		<ul class="nav navbar-nav navbar-right">
			<li class="dropdown">
			<a class="dropdown-toggle" data-toggle="dropdown" href="#">My Account<span class="caret"></span></a>
			<ul class="dropdown-menu" style="padding: 15%;align:right;" align="center">
				<li>Hello Hitesh</li>
				<li><a href="#">Logout</a></li>
			</ul>
			</li>
		</ul>
	</div>

</nav>
<div  style="padding: 5%;background-color: #ff6600;color: #fff;">
	<div class="row">
		<div class="col-sm-12">
			<h3>Type your queries</h3>
			<input type="text" name="" id="querysearch" class="form-control">
			<p class="well-lg" id="project-description"></p>
			<div id="raise_query" class="well" style="color: #ff6600;">
				<div class="form-group">
					<label>Please provide us with a Description</label>
					<textarea class="form-control"></textarea>
				</div>
				<div align="right">
					<button class="btn  btn-success">Save</button>
				</div>
			</div>
		</div>
	</div>
	<!-- <div class="row" style="margin-top: 2%;">
		<div class="col-sm-5">
			<div class="form-group">
				<label>Provide details</label>
				<textarea class="form-control"></textarea>
			</div>
			<div class="form-group">
				<label>Type to Tag departments</label>
				<input type="text" name="queries" class="form-control">
			</div>
			<div align="right">
				<button class="btn btn-success">Submit</button>
			</div>
		</div>
	</div> -->
</div>
<div class="container">
	
	<div class="row">
		<div class="col-sm-3 well-lg">
			<h4>Queries that "I" asked that are open</h4>
			<div style="max-height:400px; overflow-y: scroll;">
			<ul class="list-group">
				<li class="list-group-item">
					<div id="openquery1" class="well-lg" style="background-color: #00cc99;color: #fff; margin: 5%;">
					<div><strong>How much is fine for signal jumping?</strong></div>
					<button class="btn btn-info btn-xs sat1">Satisfied</button>
					<button class="btn btn-primary btn-xs imp1">Implemented</button>
				</li>
				<li id="openquery2" class="list-group-item" align="right">
					<div class="well-lg" style="background-color: #00cc99;color: #fff; margin: 5%;">
					<div><strong>Rickshaw guy overcharged me</strong></div>
					<button class="btn btn-info btn-xs sat2">Satisfied</button>
					<button class="btn btn-primary btn-xs imp2">Implemented</button>
				</li>
				<li id="openquery3" class="list-group-item">
					<div class="well-lg" style="background-color: #00cc99;color: #fff; margin: 5%;">
					<div><strong>Railway agents ask extra money to book tickets</strong></div>
					<button class="btn btn-info btn-xs sat3">Satisfied</button>
					<button class="btn btn-primary btn-xs imp3">Implemented</button>
				</li>
			</ul>
			</div>
			<button class="btn btn-primary btn-block">View All</button>
		</div>

		<script>
			$(document).ready(function(){
				$('.sat1').click(function(){
					$('#openquery1').remove();
				});
				$('.sat2').click(function(){
					$('#openquery2').remove();
				});
				$('.sat3').click(function(){
					$('#openquery3').remove();
				});
				$('.imp1').click(function(){
					$('#openquery1').remove();
				});
				$('.imp2').click(function(){
					$('#openquery2').remove();
				});
				$('.imp3').click(function(){
					$('#openquery3').remove();
				});
			});
		</script>
		<div class="col-sm-6 well well-lg">
			<h4>Publicly Unanswered Queries</h4>
			<div style="max-height:400px; overflow-y: scroll;">
			<ul class="list-group">
				<li class="list-group-item">
					<div>
						<strong>Mr. X asked me a bribe of Rs. 500/- to get things done.</strong>
					</div>
					<span class="badge" align="right">Pending Since: 3 days</span>
					<div>
						<em>- Civil Department</em>
					</div>
					<small>Waow waow waow waow</small>
				</li>
				<li class="list-group-item" align="right">
					<div>
						<strong>Road contractors donot show quality of materials</strong>
					</div>
					<span class="badge" align="right">Pending Since: 2 days</span>
					<div>
						<em>- Public Works Department</em>
					</div>
					<small>Waow waow waow waow</small>
				</li>
				<li class="list-group-item">
					<div>
						<strong>Cleaniness Drive on Thursday not yet conducted</strong>
					</div>
					<span class="badge" align="right">Pending Since: 2 days</span>
					<div>
						<em>- Municipality</em>
					</div>
					<small>Waow waow waow waow</small>
				</li>
				<li class="list-group-item">
					<div>
						<strong>Traffic signals have stopped working</strong>
					</div>
					<span class="badge" align="right">Pending Since: 2 days</span>
					<div>
						<em>- Traffic Police</em>
					</div>
					<small>Waow waow waow waow</small>
				</li>
			</ul>
			</div>
			<!-- <button class="btn btn-warning btn-block">View All</button> -->
		</div>
		<div class="col-sm-3 well-lg">
			<h4>Department activeness</h4>
			<canvas id="myChart" width="400" height="400"></canvas>

			<hr>
			<h4>Announcements</h4>
			<ul class="list-group">
				<li class="list-group-items">Hacakthon At Sahradaya College of Engg.</li>
				<li class="list-group-items">Swachh Bharat Abhiyan.</li>
			</ul>
		</div>
		
	</div>
</div>

<script>
$(document).ready( function(){
	$('#raise_query').hide();
});

var ctx = document.getElementById("myChart");
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ["H.R.","Education", "Municipality", "Police", "PWD", "Civil"],
        datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});
</script>

</body>
</html>