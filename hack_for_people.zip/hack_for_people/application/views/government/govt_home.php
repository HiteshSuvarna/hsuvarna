<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Govt Portal</title>
	<link rel="stylesheet" href="<?php echo base_url().'/assets/css/bootstrap.min.css'; ?>">
	<script src="<?php echo base_url().'/assets/js/jquery.min.js'; ?>"></script>
	<script src="<?php echo base_url().'/assets/js/Chart.js'; ?>"></script>
	<script src="<?php echo base_url().'/assets/js/bootstrap.min.js'; ?>"></script>

	<style type="text/css">

	</style>
</head>
<body>
<nav class="navbar">
	<div class="container-fluid">
    	<div class="navbar-header">
    		<a class="navbar-brand" href="#">Hack 4 Govt (Municipal)</a>
    	</div>
		<ul class="nav navbar-nav">
			<!-- <li><a href="#">Home</a></li> -->
			<!-- <li><a href="#">Announcements</a></li> -->
			<!-- <li><a href="#">Find Rules</a></li>
			<li><a href="#">Check Application Status</a></li> -->
		</ul>
		<ul class="nav navbar-nav navbar-right">
			<li class="dropdown">
			<a class="dropdown-toggle" data-toggle="dropdown" href="#">My Account<span class="caret"></span></a>
			<ul class="dropdown-menu" style="padding: 15%;align:right;" align="center">
				<li>Hello Hitesh</li>
				<li><a href="#">Logout</a></li>
			</ul>
			</li>
		</ul>
	</div>

</nav>
<div class="container">
	<div class="row">
		
	</div>
	<div class="row">
		<div class="col-sm-4" style="background-color: #cc0000; color: #fff;max-height: 100%;">
			<button type="button" data-toggle="modal" data-target="#viewqueries" class="btn btn-block" style="padding: 2%;color: #cc0000;margin-top : 2%;">View all queries</button>
			<div class="row">
				<div class="col-sm-4">
					<h3>Newly Raised Queries <span class="badge">3</span></h3>
					<hr>
				</div>
				<div class="col-sm-8"></div>
			</div>
			<div class="row" style="background-color: #fff;">
				<div class="col-sm-12">
					<div style="max-height:400px; overflow-y: scroll;">
					<ul class="list-group" style="color: #cc0000;">
						<li class="list-group-item">
							<div><em>Hitesh Suvarna</em></div>
							<div>
								<blockquote>Can a remove a wall from my hallroom?<footer>15/10/2016</footer></blockquote>
								<div align="right">
									<button type="button" data-toggle="modal" data-target="#allot1" class="btn btn-danger btn-xs">Allot</button>
									<button type="button" data-toggle="modal" data-target="#answer1" class="btn btn-danger btn-xs">Answer</button>
								</div>
							</div>

						</li>
						<li class="list-group-item">
							<div><em>Hitesh Suvarna</em></div>
							<div>
								<blockquote>There are no proper arrangements for Garbage Removal from my surrounding</blockquote>
								<div align="right">
									<button type="button" data-toggle="modal" data-target="#allot1" class="btn btn-danger btn-xs">Allot</button>
									<button type="button" data-toggle="modal" data-target="#answer2" class="btn btn-danger btn-xs">Answer</button>
								</div>
							</div>

						</li>
						<li class="list-group-item">
							<div><em>Hitesh Suvarna</em></div>
							<div>
								<blockquote>What is the fine for cutting down a tree?</blockquote>
								<div align="right">
									<button type="button" data-toggle="modal" data-target="#allot1" class="btn btn-danger btn-xs">Allot</button>
									<button type="button" data-toggle="modal" data-target="#answer3" class="btn btn-danger btn-xs">Answer</button>
								</div>
							</div>

						</li>
					</ul>
					</div>
				</div>
				
			</div>
		</div>
		<div class="col-sm-4" style="background-color: #1e434c; color: #fff;max-height: 100%;box-shadow: 0px 5px 2px #000;">
			<button type="button" data-toggle="modal" data-target="#publicopinion" class="btn btn-block" style="padding: 2%;margin-top: 2%;color: #1e434c;">Ask for an public opinion</button>
			<div class="row">
				<div class="col-sm-4"></div>
				<div class="col-sm-4" align="center">
					<h3>Recent Public Opinions<span class="badge">2</span></h3>
					<hr>
				</div>
				<div class="col-sm-4"></div>
			</div>
			<div class="row">
				<div class="col-sm-12">
					<div style="max-height:400px; overflow-y: scroll;">
					<ul class="list-group" style="color: #1e434c;">
						<li class="list-group-item">
							<div>
								<h3>Do we need wider roads?</h3>
								<small>We are facing huge traffic problems. As a result of which we are not able to ....</small>
								<div align="right">
									<em id="opinion1_yes_view" style="background-color: green; color: #fff;padding: 2%;border-radius: 3px;box-shadow: 0px 2px 3px #000;">49</em>
									<em id="opinion1_no_view" style="background-color: red; color: #fff;padding: 2%;border-radius: 3px;box-shadow: 0px 2px 3px #000;">2</em>
									<div style="margin-top: 5%;"><em>Raised on 30/10/2016 by <b>Mr. Kumar (Director, PWD)</b></em></div>
								</div>
								<div align="rig">
									<button type="button" data-toggle="modal" data-target="#opinion1" class="btn btn-xs" style="background-color: #1e434c; color: #fff;">View Details</button>
								</div>
							</div>

						</li>
						<li class="list-group-item">
							<div>
								<h3>A better power generating mechnaism to prevent frequent failures</h3>
								<small>In our kerela we have obsereved frequent power failure, which results in a lot ....</small>
								<div align="right">
									<em id="opinion2_yes_view" style="background-color: green; color: #fff;padding: 2%;border-radius: 3px;box-shadow: 0px 2px 3px #000;">103</em>
									<em id="opinion2_no_view" style="background-color: red; color: #fff;padding: 2%;border-radius: 3px;box-shadow: 0px 2px 3px #000;">0</em>
									<div style="margin-top: 5%;"><em>Raised on 12/10/2016 by <b>Mr. Nair (Executive, Electricity Supply Board)</b></em></div>
								</div>
								<div align="rig">
									<button  type="button" data-toggle="modal" data-target="#opinion2" class="btn btn-xs" style="background-color: #1e434c; color: #fff;">View Details</button>
								</div>
							</div>
						</li>						
					</ul>
					</div>
				</div>
				
			</div>
		</div>
		<div class="col-sm-4" style="background-color: #c99e10; color: #fff;max-height: 100%;">
			<button type="button" data-toggle="modal" data-target="#raiseannounce" class="btn btn-block" style="padding: 2%; color: #c99e10; margin-top: 2%;">Raise an announcement</button>
			<div class="row">
				<div class="col-sm-7"></div>
				<div class="col-sm-5" align="right">
					<h3>Publicly Announced Statements<span class="badge">2</span></h3>
					<hr>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12"  style="background-color: #fff; margin : 1px;">
					<div style="max-height:400px; overflow-y: scroll;">
					<ul class="list-group" style="color: #1e434c;">
						<li class="list-group-item">
							<div>
								<h3>Hacakthon At Sahradaya College of Engg.</h3>
								<div align="justified">
								<em>We are proud to announce that we are announcing a hack 4 people hackathon inviting people from all over the country to make technological solutions against corruption. The event will start on the 3rd ...</em>
								</div>
								<div align="">
									<button type="button" data-toggle="modal" data-target="#announcement1" class="btn btn-block btn-xs btn-warning">View Details</button>
								</div>
							</div>

						</li>
						<li class="list-group-item">
							<div>
								<h3>Swachh Bharat Abhiyan.</h3>
								<div align="justified">
								<em> Swachh Bharat Abhiyan (English: Clean India Mission), abbreviated as SBA or SBM, is a national campaign by the Government of India, covering 4,041 statutory cities and towns, to clean the streets, roads and infrastructure of the country...</em>
								</div>
								<div align="">
									<button type="button" data-toggle="modal" data-target="#announcement2" class="btn btn-block btn-xs btn-warning">View Details</button>
								</div>
							</div>

						</li>
					</ul>
					</div>
				</div>
				
			</div>
		</div>
	</div>

</div>

<!-- Modal Windows -->

<div id="viewqueries" class="modal fade" role="dialog">
	<div class="modal-dialog">
	<!-- Modal content-->
		<div class="modal-content">
			<!-- <div class="alert alert-success" id="allot_success1">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Success!</strong> Succefully Alloted.
			</div> -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Queries</h4>
			</div>
			<div class="modal-body">
				<ul class="list-group" style="color: #cc0000;">
					<li class="list-group-item">
						<div><em>Hitesh Suvarna</em></div>
						<div>
							<blockquote>Can a remove a wall from my hallroom?<footer>15/10/2016</footer></blockquote>
							<div align="right">
								<button type="button" data-toggle="modal" data-target="#allot1" class="btn btn-danger btn-xs">Allot</button>
								<button type="button" data-toggle="modal" data-target="#answer1" class="btn btn-danger btn-xs">Answer</button>
							</div>
						</div>

					</li>
					<li class="list-group-item">
						<div><em>Hitesh Suvarna</em></div>
						<div>
							<blockquote>There are no proper arrangements for Garbage Removal from my surrounding</blockquote>
							<div align="right">
								<button type="button" data-toggle="modal" data-target="#allot1" class="btn btn-danger btn-xs">Allot</button>
								<button type="button" data-toggle="modal" data-target="#answer2" class="btn btn-danger btn-xs">Answer</button>
							</div>
						</div>

					</li>
					<li class="list-group-item">
						<div><em>Hitesh Suvarna</em></div>
						<div>
							<blockquote>What is the fine for cutting down a tree?</blockquote>
							<div align="right">
								<button type="button" data-toggle="modal" data-target="#allot1" class="btn btn-danger btn-xs">Allot</button>
								<button type="button" data-toggle="modal" data-target="#answer3" class="btn btn-danger btn-xs">Answer</button>
							</div>
						</div>

					</li>
				</ul>
			</div>
			<div class="modal-footer">
				
			</div>
		</div>
	</div>
</div>

<div id="publicopinion" class="modal fade" role="dialog">
	<div class="modal-dialog">
	<!-- Modal content-->
		<div class="modal-content">
			<!-- <div class="alert alert-success" id="allot_success1">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Success!</strong> Succefully Alloted.
			</div> -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Ask a public opinion to gather more insights to your governance.</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label>Title</label>
					<input type="text" name="" class="form-control">
				</div>
				<div class="form-group">
					<label>Details</label>
					<textarea class="form-control"></textarea>
				</div>

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-success" id="save_allot1">Save</button>
			</div>
		</div>
	</div>
</div>

<div id="raiseannounce" class="modal fade" role="dialog">
	<div class="modal-dialog">
	<!-- Modal content-->
		<div class="modal-content">
			<!-- <div class="alert alert-success" id="allot_success1">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Success!</strong> Succefully Alloted.
			</div> -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">An announcement that will make citizens aware of your good doings to the society.</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label>Title</label>
					<input type="text" name="" class="form-control">
				</div>
				<div class="form-group">
					<label>Details</label>
					<textarea class="form-control"></textarea>
				</div>

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-success" id="save_allot1">Save</button>
			</div>
		</div>
	</div>
</div>

<div id="allot1" class="modal fade" role="dialog">
	<div class="modal-dialog">
		
			
	<!-- Modal content-->
		<div class="modal-content">
			<!-- <div class="alert alert-success" id="allot_success1">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Success!</strong> Succefully Alloted.
			</div> -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Allot</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label>Select Official</label>
					<select class="form-control">
						<option>Mr. Kumar</option>
						<option>Mr. Nair</option>
						<option>Mrs. Menon</option>
						<option>Mrs. Krishnan</option>
						<option>Mr. Iyer</option>
					</select>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-success" id="save_allot1">Save</button>
			</div>
		</div>
	</div>
</div>

<div id="answer1" class="modal fade" role="dialog">
	<div class="modal-dialog">
		
	<!-- Modal content-->
		<div class="modal-content">
			<!-- <div class="alert alert-success" id="allot_success1">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Success!</strong> Succefully Alloted.
			</div> -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Hitesh Suvarna - "Can a remove a wall from my hallroom?"</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label>Answer</label>
					<textarea class="form-control"></textarea>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-success" id="save_answer1">Save</button>
			</div>
		</div>
	</div>
</div>

<div id="answer2" class="modal fade" role="dialog">
	<div class="modal-dialog">
		
	<!-- Modal content-->
		<div class="modal-content">
			<!-- <div class="alert alert-success" id="allot_success1">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Success!</strong> Succefully Alloted.
			</div> -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Hitesh Suvarna - "There are no proper arrangements for Garbage Removal from my surrounding"</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label>Answer</label>
					<textarea class="form-control"></textarea>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-success" id="save_answer2">Save</button>
			</div>
		</div>
	</div>
</div>

<div id="answer3" class="modal fade" role="dialog">
	<div class="modal-dialog">
		
	<!-- Modal content-->
		<div class="modal-content">
			<!-- <div class="alert alert-success" id="allot_success1">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Success!</strong> Succefully Alloted.
			</div> -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Hitesh Suvarna - "What is the fine for cutting down a tree?"</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label>Answer</label>
					<textarea class="form-control"></textarea>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-success" id="save_answer3">Save</button>
			</div>
		</div>
	</div>
</div>

<div id="opinion1" class="modal fade" role="dialog">
	<div class="modal-dialog">
		
	<!-- Modal content-->
		<div class="modal-content">
			<!-- <div class="alert alert-success" id="allot_success1">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Success!</strong> Succefully Alloted.
			</div> -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Do we need wider roads?</h4>
			</div>
			<div class="modal-body">
				<div><i> - Mr. Kumar, Director, PWD.</i></div>
				<div><i>Raised on 30/10/2016</i></div>


				<div align="right">
					<em><button id="opinion1_yes" style="background-color: green; color: #fff;padding: 2%;border-radius: 3px;box-shadow: 0px 2px 3px #000;"></button></em>
					<button id="opinion1_no" style="background-color: red; color: #fff;padding: 2%;border-radius: 3px;box-shadow: 0px 2px 3px #000;"><em></em></button>
				</div>
				<div class="form-group">
					<label>Details</label>
					<p>
					We are facing huge traffic problems. As a result of which we are not able to make moves faster. In 2010, Politicians in Kerala, cutting across party lines, decided to restrict the width of National Highways in the State to 30 meters. Later, through the intervention of the National Highways Authority of India (NHAI), it was decided to have 45 meters width with 4 lanes, wherever possible and 30 meters, in other places, at a time when other States opted for NHs with minimum 60 meters width with 6 lanes.</p>

					<p>Today, the average speed on the NHs in Kerala is about 30 Km/hr. On an average, 12 deaths are reported daily on account of accidents on NHs. The amount of time, money, manpower, fuel and other resources wasted on these NHs because of slow moving traffic has never been calculated.</p>

					<p>Looking at the growth of vehicular traffic, what we need is NHs with minimum 70 meters width with 8 lanes (4 + 4 dual carriageway). Wherever land acquisition is a problem, like in junctions or severely congested areas, there should be flyovers and we also need bypass for all major cities on the NHs - Kollam, Alappuzha, Kozhikode and Kannur.</p>

					<p>After three years, now the State Government is pushing the Union Ministry of Road Transport and Highways to agree to reduce the width of NH being developed in the State from 45 metres to 30 metres. But the NHAI is opposing this. NHAI has already scrapped six projects in Kerala due to non-availability of land which is the responsibility of the State Government.</p>
				</div>
				<label>Comments</label>
				<hr>
				<div class="row">
					<div class="col-sm-1"></div>
					<div class="col-sm-11">
						<div>
							<ul class="list-group">
								<li class="list-group-item">
									<label>Mr Chintan</label>
									<div align="right">01/11/2016</div>
									<div>Yes we do need wider roads, as vehicles in kerela are on the rise. This will lead to faster commute</div>

								</li>
								<li class="list-group-item">
									<label>Mr Ravi</label>
									<div align="right">01/11/2016</div>
									<div>70 meters width with 8 lanes (4 + 4 dual carriageway) would be really great.</div>

								</li>
								<li class="list-group-item" style="background-color: green;color: white;">
									<label>Mr Gujral</label>
									<div align="right">02/11/2016</div>
									<div>Let us consider what budget will be alloted to us by the government.</div>

								</li>
							</ul>
						</div>
					</div>
					
				</div>

			</div>
			<div class="modal-footer">
				<div class="form-group">
					<label>Add a comment</label>
					<textarea class="form-control"></textarea>
				</div>
				<button class="btn btn-success">Submit</button>
			</div>
		</div>
	</div>
</div>

<div id="opinion2" class="modal fade" role="dialog">
	<div class="modal-dialog">
		
	<!-- Modal content-->
		<div class="modal-content">
			<!-- <div class="alert alert-success" id="allot_success1">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Success!</strong> Succefully Alloted.
			</div> -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">A better power generating mechnaism to prevent frequent failures</h4>
			</div>
			<div class="modal-body">
				<div><i> - Mr. Nair, Executive, Electricity Supply Board.</i></div>
				<div><i>Raised on 12/10/2016</i></div>


				<div align="right">
					<em><button id="opinion2_yes" style="background-color: green; color: #fff;padding: 2%;border-radius: 3px;box-shadow: 0px 2px 3px #000;"></button></em>
					<em><button id="opinion2_no" style="background-color: red; color: #fff;padding: 2%;border-radius: 3px;box-shadow: 0px 2px 3px #000;"></button></em>
				</div>
				<div class="form-group">
					<label>Details</label>
					<p>
					In our kerela we have obsereved frequent power failure, which results in a lot Kerala State Electricity Board, constituted by the Government of Kerala, by order dated 7.3.1957, under the Electricity (Supply) Act, 1948 is in the business of Generation, Transmission and Distribution of electricity and striving to provide quality electricity at affordable cost to all classes of consumers in the state of Kerala. As per section 172 (a) of the Electricity Act 2003 and as mutually decided by the Government of India and Government of Kerala, KSEB has continued as Transmission utility and Distribution licensee till 24-09-2008. In exercise of powers conferred under sub-sections (1), (2), (5), (6) and (7) of section 131 of the Electricity Act, 2003, State Government vide the notification G.O (Ms).37/2008/PD dated 25 September 2008 has vested all functions, properties, interests, rights, obligations and liabilities of KSEB with the State Government till it is re-vested the same in a corporate entity. Accordingly, KSEB has been continuing all the functions as a Generator, State Transmission Utility and a Distribution Licensee in the State. Kerala State Electricity Board commenced functioning on 31-3-1957 After Noon as per order no. EL1-6475/56/PW dated 7-3-1957 of the Kerala State Government..</p>
				</div>
				<label>Comments</label>
				<hr>
				<div class="row">
					<div class="col-sm-1"></div>
					<div class="col-sm-11">
						<div>
							<ul class="list-group">
								<li class="list-group-item">
									<label>Mr Mahesh</label>
									<div align="right">14/10/2016</div>
									<div>Kerala State Electricity Board, constituted by the Government of Kerala, by order dated 7.3.1957, under the Electricity (Supply) Act, 1948 is in the business of Generation, Transmission and Distribution of electricity and striving to provide quality electricity at affordable cost to all classes of consumers in the state of Kerala</div>

								</li>
								<li class="list-group-item" style="background-color: green;color: white;">
									<label>Mr Ravi</label>
									<div align="right">01/11/2016</div>
									<div>Renewalble sources are great. We must implement them always.</div>

								</li>
								<li class="list-group-item">
									<label>Mr Gujral</label>
									<div align="right">02/11/2016</div>
									<div>Let us consider what budget will be alloted to us by the government.</div>

								</li>
							</ul>
						</div>
					</div>
					
				</div>

			</div>
			<div class="modal-footer">
				<div class="form-group">
					<label>Add a comment</label>
					<textarea class="form-control"></textarea>
				</div>
				<button class="btn btn-success">Submit</button>
			</div>
		</div>
	</div>
</div>

<div id="announcement1" class="modal fade" role="dialog">
	<div class="modal-dialog">
		
	<!-- Modal content-->
		<div class="modal-content">
			<!-- <div class="alert alert-success" id="allot_success1">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Success!</strong> Succefully Alloted.
			</div> -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Hacakthon At Sahradaya College of Engg</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label>Details</label>
					<p>As we know, one of the most challenging problems that our nation have been facing is the invincible tentacles of Corruption.We believe that technical solutions can prevent many people to be a part of this deadly menace. We strongly feel that robust technological solutions can fight corruption in the country, than anything else.</p>

					<p>With this view and in the wake of newly inspired "Digital India Drive", We the Innovation & Entrepreneurship Development Center (IEDC) of Sahrdaya College of Engineering & Technology, Thrissur, Kerala in collaboration with Kerala Startup mission,Kerala Institute of local Administration, Digital India, MyGov, Hackerearth and Github , is organising a Hackathon on " Smart Technological Solutions Against Corruption" .</p>

					<p>A hackathon is an event in which engineering professionals and others involved in software development and hardware development, collaborate intensively (continuous 30 hour program we are proposing) on technological challenges. The technocrats will develop different ideas to increase transparency in any system and come up with technical solutions to solve the identified problem.</p>

					<p>The event is scheduled as two separate events, Preliminary and Main. Participants have to qualify the preliminary Stage to participate in main Hackathon. Preliminary Stage is an online platform where participants can submit the works done by them. From this participants best performers will be selected to HackPeople hackathon conducting on 3rd 4th and 5th of November, 2016 at Sahrdaya College of engineering and Technology.</p>

					<p>The venue is nearer to Athirappilly waterfalls in Kerala which is named as God's own country.</p>

					<p>The proposed program will give a real awareness against corruption among the youth.We expect your collaboration and participation in hackathon which we developed out of patriotism to utilize our technocrats in nation building and request you to promote this event for the betterment of our country.

					</p>
				</div>
					
			</div>

			</div>
			<div class="modal-footer">
			
			</div>
		</div>
	</div>
</div>

<div id="announcement2" class="modal fade" role="dialog">
	<div class="modal-dialog">
		
	<!-- Modal content-->
		<div class="modal-content">
			<!-- <div class="alert alert-success" id="allot_success1">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Success!</strong> Succefully Alloted.
			</div> -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Swachh Bharat Abhiyan.</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label>Details</label>
					<p>Swachh Bharat Abhiyan (English: Clean India Mission), abbreviated as SBA or SBM, is a national campaign by the Government of India, covering 4,041 statutory cities and towns, to clean the streets, roads and infrastructure of the country.</p>

					<p>The campaign was officially launched on 2 October 2014 at Rajghat, New Delhi, by Prime Minister Narendra Modi. It is India's biggest ever cleanliness drive and 3 million government employees and school and college students of India participated in this event.</p>

					<p>With effect from 1 April 1999, the Government of India restructured the Comprehensive Rural Sanitation Programme and launched the Total Sanitation Campaign (TSC) which was later (on 1 April 2012) renamed Nirmal Bharat Abhiyan (NBA).[6][7]</p>

					<p>On 2 October 2014, Prime Minister of India Narendra Modi launched the Swachh Bharat Mission, which aims to eradicate open defecation by 2019,[8] thus restructuring the Nirmal Bharat Abhiyan.[7] Swachh Bharat Abhiyan is a national campaign, covering 4,041 statutory cities and towns</p>
				</div>					
			</div>

			</div>
			<div class="modal-footer">
			
			</div>
		</div>
	</div>
</div>

<script>
	$('#allot_success1').modal('hide');
	$(document).ready(function(){
		var opinion1yes = 49;
		var opinion1no = 23;
		var opinion2yes = 123;
		var opinion2no = 0;

		$('#opinion1_yes').html(opinion1yes);
		$('#opinion1_no').html(opinion1no);
		$('#opinion2_yes').html(opinion2yes);
		$('#opinion2_no').html(opinion2no);
		$('#opinion1_yes_view').html(opinion1yes);
		$('#opinion1_no_view').html(opinion1no);
		$('#opinion2_yes_view').html(opinion2yes);
		$('#opinion2_no_view').html(opinion2no);
		
		$('#save_allot1').click(function(){
			$('#allot_success1').modal('show');
				setTimeout(function(){
					$("#allot_success1").modal('hide');
					$('.modal').modal('hide');
					$('.modal-backdrop').remove();
					editcnt=0;
					cnt=0;
				}, 1000);
		});

		$('#save_answer1').click(function(){
			$('#allot_success1').modal('show');
				setTimeout(function(){
					$("#allot_success1").modal('hide');
					$('.modal').modal('hide');
					$('.modal-backdrop').remove();
					editcnt=0;
					cnt=0;
				}, 1000);
		});

		$('#save_answer2').click(function(){
			$('#allot_success2').modal('show');
				setTimeout(function(){
					$("#allot_success1").modal('hide');
					$('.modal').modal('hide');
					$('.modal-backdrop').remove();
					editcnt=0;
					cnt=0;
				}, 1000);
		});

		$('#save_answer3').click(function(){
			$('#allot_success3').modal('show');
				setTimeout(function(){
					$("#allot_success1").modal('hide');
					$('.modal').modal('hide');
					$('.modal-backdrop').remove();
					editcnt=0;
					cnt=0;
				}, 1000);
		});

		// $('#opinion1_yes').click(function(){
		// 	opinion1yes++;
		// 	$('#opinion1_yes').html(opinion1yes);
		// 	$('#opinion1_yes_view').html(opinion1yes);
		// });
		
		// $('#opinion1_no').click(function(){
		// 	opinion1no++;
		// 	$('#opinion1_no').html(opinion1no);
		// 	$('#opinion1_no_view').html(opinion1no);
		// });
		
		// $('#opinion2_yes').click(function(){
		// 	opinion2yes++;
		// 	$('#opinion2_yes').html(opinion2yes);
		// 	$('#opinion2_yes_view').html(opinion2yes);
		// });
		
		// $('#opinion2_no').click(function(){
		// 	opinion2no++;
		// 	$('#opinion2_no').html(opinion2no);
		// 	$('#opinion2_no_view').html(opinion2no);
		// });
		
	});

</script>

</div>
<script>
var data = {
    labels: [
        "Red",
        "Blue",
        "Yellow"
    ],
    datasets: [
        {
            data: [300, 50, 100],
            backgroundColor: [
                "#FF6384",
                "#36A2EB",
                "#FFCE56"
            ],
            hoverBackgroundColor: [
                "#FF6384",
                "#36A2EB",
                "#FFCE56"
            ]
        }]
};

var ctx = document.getElementById("myChart");
var myPieChart = new Chart(ctx,{
    type: 'pie',
    data: data,
//    options: options
});
</script>

<script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover();
});
</script>
</body>
</html>