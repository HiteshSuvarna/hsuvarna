<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Govt Portal</title>
	<link rel="stylesheet" href="<?php echo base_url().'/assets/css/bootstrap.min.css'; ?>">
	<script src="<?php echo base_url().'/assets/js/jquery.min.js'; ?>"></script>
	<script src="<?php echo base_url().'/assets/js/bootstrap.min.js'; ?>"></script>

	<style type="text/css">

	</style>
</head>
<body>
<nav class="navbar">
	<div class="container-fluid">
    	<div class="navbar-header">
    		<a class="navbar-brand" href="#">Hack 4 Govt</a>
    	</div>
		<ul class="nav navbar-nav">
			<li><a href="#">Home</a></li>
			<li><a href="#">Announcements</a></li>
			<!-- <li><a href="#">Find Rules</a></li>
			<li><a href="#">Check Application Status</a></li> -->
		</ul>
		<ul class="nav navbar-nav navbar-right">
			<li class="dropdown">
			<a class="dropdown-toggle" data-toggle="dropdown" href="#">My Account<span class="caret"></span></a>
			<ul class="dropdown-menu" style="padding: 15%;align:right;" align="center">
				<li>Hello Hitesh</li>
				<li><a href="#">Logout</a></li>
			</ul>
			</li>
		</ul>
	</div>

</nav>
<div class="container">
	<h3>Announcements</h3>
	<div class="row">
		<div class="col-sm-12 form-group">
			<label>Type the department name</label>
			<input type="text" name="" class="form-control">
		</div>
		<div class="col-sm-6">
			Results found <span class="badge">15</span>
		</div>
		<div class="form-group col-sm-6" align="right">
			Sort by 
			<select>
				<option>Latest</option>
				<option>Oldest</option>
			</select>
		</div>
		<div class="col-sm-12">
			<ul class="list-group">
				<li class="list-group-item">
					<div>
						<strong>We have built temples today!!</strong>
					</div>
					<div>
						<em>- Civil Department</em>
					</div>
					<small>Waow waow waow waow</small>
				</li>
				<li class="list-group-item" align="right">
					<div>
						<strong>Road works done!!</strong>
					</div>
					<div>
						<em>- Public Works Department</em>
					</div>
					<small>Waow waow waow waow</small>
				</li>
				<li class="list-group-item">
					<div>
						<strong>Cleaniness Drive on Thursday</strong>
					</div>
					<div>
						<em>- Municipality</em>
					</div>
					<small>Waow waow waow waow</small>
				</li>
				<li class="list-group-item">
					<div>
						<strong>Roads would be blocked</strong>
					</div>
					<div>
						<em>- Traffic Police</em>
					</div>
					<small>Waow waow waow waow</small>
				</li>
			</ul>
		</div>
	</div>
</div>

</body>
</html>