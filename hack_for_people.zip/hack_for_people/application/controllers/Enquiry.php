<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Enquiry extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()	{
		parent:: __construct();
		$this->load->database();
		$this->load->helper('url');
	}

	public function index()
	{
		$this->load->view('enquiry/enquiry');
	}

	public function save() {
		$dt = date('Y-m-d H:m:s');
		$data = array(
			'enq_f_name' => $this->input->post('first_name'),
			'enq_l_name' => $this->input->post('last_name'),
			'enq_address' => $this->input->post('address'),
			'enq_phone1' => $this->input->post('phone1'),
			'enq_phone2' => $this->input->post('phone2'),
			'enq_phone3' => $this->input->post('phone3'),
			'enq_email' => $this->input->post('email'),
			'enq_course' => $this->input->post('course'),
			'enq_gender' => $this->input->post('gender'),
			'enq_refer' => $this->input->post('refer'),
			'enq_create' => $dt,
		);

		$this->db->insert('asc_enquires', $data);
		echo ('Done');
	}
}
