<?php
//defined('BASEPATH') OR exit('No direct script access allowed');

class HMonitor extends CI_Controller {

	public function __construct()	{
		parent:: __construct();
		$this->load->database();
		$this->load->helper('url');
	}

	public function index()
	{
		$this->load->view('public/public_login');
	}

	public function home()
	{
		$this->load->view('government/govt_home');
	}

	public function announce()
	{
		$this->load->view('public/public_announce');
	}




}
