<?php
//defined('BASEPATH') OR exit('No direct script access allowed');

class HPublic extends CI_Controller {

	public function __construct()	{
		parent:: __construct();
		$this->load->database();
		$this->load->helper('url');
	}

	public function index()
	{
		$this->load->view('public/public_login');
	}

	public function home()
	{
		$this->load->view('public/public_home');
	}

	public function opinions()
	{
		$this->load->view('public/public_opinions');
	}




}
